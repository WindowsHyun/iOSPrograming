import UIKit
import MapKit

class Character: MKCircle{
    
    var name: String?
    var color: UIColor?
}